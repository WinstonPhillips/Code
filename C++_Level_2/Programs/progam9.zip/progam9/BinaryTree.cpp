/*********************************************************************************
 *     Title:   BinaryTree.cpp                                                   *
 *     Author:  Winston Phillips                                                 *
 *     Date:    March 29, 2018                                                   *
 *     Purpose: This is the implementation file for the BinaryTree class, which  *
 *              is an implementation of a Binary Search Tree.  Each Tree Node    *
 *              stores a customer name (string) and the number of Krabby Patties *
 *              the customer ate.                                                *
 *********************************************************************************/
#include <iostream>
#include <string>
#include <stdio.h>
#include "BinaryTree.h"

using namespace std;

BinaryTree::BinaryTree()
{
	root = NULL;
}

BinaryTree::~BinaryTree()
{
	destroySubtree(root);
}

void BinaryTree::insertNode(string custName, int eatenPatties)
{
	TreeNode* newNode = new TreeNode;

	newNode->name = custName;
	newNode->numPattiesEaten = eatenPatties;

	newNode->leftChild = NULL;
	newNode->rightChild = NULL;
	insert(root,newNode); 
	root = balance(root);
}

void BinaryTree::displayInOrder() // the public function
{
	displayInOrder(root);
}

void BinaryTree::getLeastNumPatties(string &name, int &numPatties)
{
	numPatties = 999999;
	getLeast(root, name, numPatties);
}
void BinaryTree::getMostNumPatties(string &name, int &numPatties) // sending values that ought to be changed
{
	numPatties = 0;
	getMost(root, name, numPatties);
}

int BinaryTree::searchNode(string name)
{
	TreeNode* nodePtr = root;

	while (nodePtr != NULL)
	{
			if (name == nodePtr->name)
			{
				return nodePtr->numPattiesEaten;
			}
			else if (name > nodePtr->name)
			{
				nodePtr = nodePtr->rightChild;
			}
			else
			{
				nodePtr = nodePtr->leftChild;
			}
	}

	return -1;
}

int BinaryTree::getTotalNumPatties()
{
	int totalPatties = 0;
	getTotal(totalPatties,root);
	return totalPatties;
}

int BinaryTree::difference(TreeNode* nodePtr)
{
	int left_height = getHeight(nodePtr->leftChild);
	int right_height = getHeight(nodePtr->rightChild);
	int difference = (left_height - right_height);
	return difference;
}

void BinaryTree::displayPublic()
{
	display(root,1);
}







