/*********************************************************************************
 *     Title:   BinaryTree.h                                                     *
 *     Author:  Winston Phillips                                                 *
 *     Date:    March 29, 2018                                                   *
 *     Purpose: This is the specification file for the BinaryTree class, which   *
 *              is an implementation of a Binary Search Tree.  Each Tree Node    *
 *              stores a customer name (string) and the number of Krabby Patties *
 *              the customer ate.                                                *
 *********************************************************************************/
#ifndef BINARYTREE_H
#define BINARYTREE_H

#include <iostream>
#include <string>

using namespace std;


class BinaryTree
{
		private: 

			struct TreeNode
			{
					string name;
					int numPattiesEaten;
					TreeNode* leftChild;
					TreeNode* rightChild;
			};

			TreeNode* root;		// head of tree

///////////////**PRIVATE FUNCTIONS**/////////////////////

			void insert(TreeNode* &nodePtr, TreeNode* &newNode)
			{
				if(nodePtr == NULL)
				{
					nodePtr = newNode;	// where passing by reference actually matters
					root = balance(root);
				}
				else if(newNode->name > nodePtr->name) 
				{
					insert(nodePtr->rightChild,newNode); // initiiate right branch search
					root = balance(root);
				}
				else 
				{
					insert(nodePtr->leftChild,newNode); // initiate left branch search
					root = balance(root);
				}

			}

			TreeNode* displayInOrder(TreeNode* currNode)
			{
				if (currNode != NULL)
				{
					displayInOrder(currNode->leftChild); //after recursion, we will have our leftmost leaf in our tree
					cout << "Customer : "<< currNode->name << endl;
					displayInOrder(currNode->rightChild);
				}
			}


			void getLeast(TreeNode* currNode, string &nameOfLeast, int &least)
			{

				if (currNode != NULL)
				{
			
					getLeast(currNode->leftChild, nameOfLeast, least);

					if(currNode->numPattiesEaten < least)
					{
						least = currNode->numPattiesEaten;
						nameOfLeast = currNode->name;
					}

					getLeast(currNode->rightChild, nameOfLeast, least);
					
				}
				
			}
			void getMost(TreeNode* currNode, string &nameOfMost, int &most)
			{

				if (currNode != NULL)
				{
			
					getMost(currNode->leftChild, nameOfMost, most);

					if(currNode->numPattiesEaten > most)
					{
						most = currNode->numPattiesEaten;
						nameOfMost = currNode->name;
					}

					getMost(currNode->rightChild, nameOfMost, most);
					
				}
				
			}

		void getTotal(int &total, TreeNode* currNode)
		{

			 if (currNode != NULL)
				{
			
					getTotal(total, currNode->leftChild);

					total = total + currNode->numPattiesEaten;

					getTotal(total, currNode->rightChild);
					
				}

		}
		void destroySubtree(TreeNode* &currNode)
		{
			if (currNode != NULL)
				{
					destroySubtree(currNode->leftChild); 
					delete currNode;
					destroySubtree(currNode->rightChild);
				}
		}

		int getHeight(TreeNode* nodePtr)
		{
			int height = 0;
			 if (nodePtr != NULL)
			 {
			 	int left_height = getHeight(nodePtr->leftChild);
			 	int right_height = getHeight(nodePtr->rightChild);
			 	int max_height = max(left_height,right_height);
			 	height = max_height + 1;
			 }
			 return height;
		}

		TreeNode* balance(TreeNode* nodePtr)
		{
			int balance_factor = difference(nodePtr);

			if (balance_factor > 1)
			{
				if (difference(nodePtr->leftChild) > 0)
				{
					nodePtr = rr_rotation(nodePtr);
						cout << "Right Right Rotation" << endl;
				}
				else
				{
					nodePtr = lr_rotation(nodePtr);
						cout << "Left Right Rotation" << endl;
				}
			}
			else if (balance_factor < -1)
			{
				if (difference(nodePtr->rightChild) > 0)
				{
					nodePtr = rl_rotation(nodePtr);
						cout << "Right Left Rotation" << endl;
				}
				else
				{
					nodePtr = ll_rotation(nodePtr);
						cout << "Left Left Rotation" << endl;
				}
			}

			return nodePtr;
	    }

		TreeNode* ll_rotation(TreeNode* parent)
		{
			TreeNode* nodePtr = parent->rightChild;

			parent->rightChild = nodePtr->leftChild;

			nodePtr->leftChild = parent;

			return nodePtr;
		}

		TreeNode* rr_rotation(TreeNode* parent)
		{
			TreeNode* nodePtr = parent->leftChild;

			parent->leftChild = nodePtr->rightChild;

			nodePtr->rightChild = parent;

			return nodePtr;
		}
		
		TreeNode* lr_rotation(TreeNode* parent)
		{
			TreeNode* nodePtr = parent->leftChild;

			parent->leftChild = ll_rotation(nodePtr);

			return rr_rotation(parent);
		}
				
		TreeNode* rl_rotation(TreeNode* parent)
		{
			TreeNode* nodePtr = parent->rightChild;

			parent->rightChild = rr_rotation(nodePtr);

			return ll_rotation(parent);
		}

		void display(TreeNode* nodePtr, int level)
		{
			int i;
			if(nodePtr != NULL)
			{
				display(nodePtr->rightChild, level+1);
				cout << endl;
				if (nodePtr == root)
				{
					cout << "Root--> ";
				}
					for (i = 0; i < level && nodePtr != root ; i++)
					{
						cout << "		";
					}
						cout << nodePtr->name[0] << nodePtr->name[1];
						display(nodePtr->leftChild, level+1);
					
				
			}
		}
		public:
				BinaryTree();
				~BinaryTree();
				void insertNode(string custName, int eatenPatties);
				void displayInOrder();
				int searchNode(string name);
				void getLeastNumPatties(string &name, int &numPatties);
				void getMostNumPatties(string &name, int &numPatties);
				int getTotalNumPatties();
				int difference(TreeNode* nodePtr);
				void displayPublic();
				



};


#endif