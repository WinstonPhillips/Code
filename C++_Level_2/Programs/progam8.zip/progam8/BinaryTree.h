/*********************************************************************************
 *     Title:   BinaryTree.h                                                     *
 *     Author:  Winston Phillips                                                 *
 *     Date:    March 29, 2018                                                   *
 *     Purpose: This is the specification file for the BinaryTree class, which   *
 *              is an implementation of a Binary Search Tree.  Each Tree Node    *
 *              stores a customer name (string) and the number of Krabby Patties *
 *              the customer ate.                                                *
 *********************************************************************************/
#ifndef BINARYTREE_H
#define BINARYTREE_H

#include <iostream>
#include <string>

using namespace std;


class BinaryTree
{
		private: 

			struct TreeNode
			{
					string name;
					int numPattiesEaten;
					TreeNode* leftChild;
					TreeNode* rightChild;
			};

			TreeNode* root;		// head of tree

///////////////**PRIVATE FUNCTIONS**/////////////////////

			void insert(TreeNode* &nodePtr, TreeNode* &newNode)
			{
				if(nodePtr == NULL)
				{
					nodePtr = newNode;	// where passing by reference actually matters
				}
				else if(newNode->name > nodePtr->name) 
				{
					insert(nodePtr->rightChild,newNode); // initiiate right branch search
				}
				else 
				{
					insert(nodePtr->leftChild,newNode); // initiate left branch search
				}

			}

			TreeNode* displayInOrder(TreeNode* currNode)
			{
				if (currNode != NULL)
				{
					displayInOrder(currNode->leftChild); //after recursion, we will have our leftmost leaf in our tree
					cout << "Customer : "<< currNode->name << endl;
					displayInOrder(currNode->rightChild);
				}
			}

			void deleteNode(string nameForSearch, TreeNode* &nodePtr)
			{
					if (nameForSearch > nodePtr->name && nodePtr->rightChild != NULL)
					{
						deleteNode(nameForSearch,nodePtr->rightChild);
					}
					else if (nameForSearch < nodePtr->name && nodePtr->leftChild != NULL)
					{
						deleteNode(nameForSearch,nodePtr->leftChild);
					}
					else if (nameForSearch == nodePtr->name)
					{
						makeDeletion(nodePtr);
					}
					else 
					{
						cout << "Sorry, " << nameForSearch << " is not in our Krabby databases." << endl;
					}
			}
			void makeDeletion(TreeNode* &nodeToDelete)
			{

				TreeNode* tempNode = NULL;
			
				if (nodeToDelete->leftChild == NULL)
				{
					tempNode = nodeToDelete;
					nodeToDelete = nodeToDelete->rightChild;
					delete tempNode;
				}
				else if (nodeToDelete->rightChild == NULL)
				{
					tempNode = nodeToDelete;
					nodeToDelete = nodeToDelete->leftChild;
					delete tempNode;
				} 
				else 
				{
					tempNode = nodeToDelete->rightChild;

					while(tempNode->leftChild != NULL)
					{
						tempNode = tempNode->leftChild;
					}

					tempNode->leftChild = nodeToDelete->leftChild;

					tempNode = nodeToDelete;

					nodeToDelete = nodeToDelete->rightChild;

					delete tempNode;
				}

		 }

			void getLeast(TreeNode* currNode, string &nameOfLeast, int &least)
			{

				if (currNode != NULL)
				{
			
					getLeast(currNode->leftChild, nameOfLeast, least);

					if(currNode->numPattiesEaten < least)
					{
						least = currNode->numPattiesEaten;
						nameOfLeast = currNode->name;
					}

					getLeast(currNode->rightChild, nameOfLeast, least);
					
				}
				
			}
			void getMost(TreeNode* currNode, string &nameOfMost, int &most)
			{

				if (currNode != NULL)
				{
			
					getMost(currNode->leftChild, nameOfMost, most);

					if(currNode->numPattiesEaten > most)
					{
						most = currNode->numPattiesEaten;
						nameOfMost = currNode->name;
					}

					getMost(currNode->rightChild, nameOfMost, most);
					
				}
				
			}

		void getTotal(int &total, TreeNode* currNode)
		{

			 if (currNode != NULL)
				{
			
					getTotal(total, currNode->leftChild);

					total = total + currNode->numPattiesEaten;

					getTotal(total, currNode->rightChild);
					
				}

		}
		void destroySubtree(TreeNode* &currNode)
		{
			if (currNode != NULL)
				{
					destroySubtree(currNode->leftChild); 
					delete currNode;
					destroySubtree(currNode->rightChild);
				}
		}
		public:
				BinaryTree();
				~BinaryTree();
				void insertNode(string custName, int eatenPatties);
				void displayInOrder();
				void remove(string nameForSearch);
				int searchNode(string name);
				void getLeastNumPatties(string &name, int &numPatties);
				void getMostNumPatties(string &name, int &numPatties);
				int getTotalNumPatties();


};


#endif