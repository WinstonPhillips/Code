#include <iostream>
using namespace std;

class IntNode {
	public:
	   IntNode(int dataInit = 0, IntNode* nextLoc = NULL);
	   void InsertAfter(IntNode* nodePtr);
	   IntNode* GetNext();
	   void PrintNodeData();
	private:
	   int dataVal;
	   IntNode* nextNodePtr;
};

// Constructor
IntNode::IntNode(int dataInit, IntNode* nextLoc) {
   this->dataVal = dataInit;
   this->nextNodePtr = nextLoc;
}

/* Insert node after this node.
 * Before: this -- next
 * After:  this -- node -- next
 */
void IntNode::InsertAfter(IntNode* nodeLoc) {
   IntNode* tmpNext = NULL;
   
   tmpNext = this->nextNodePtr;    // Remember next
   this->nextNodePtr = nodeLoc;    // this -- node -- ?
   nodeLoc->nextNodePtr = tmpNext; // this -- node -- next
   
   return;
}


void IntNode::PrintNodeData() {
   cout << this->dataVal << endl;
}
IntNode* IntNode::GetNext() {
   return this->nextNodePtr;
}

int main() {
   IntNode* headObj  = NULL; // Create intNode objects
   IntNode* nodeObj1 = NULL;
   IntNode* nodeObj2 = NULL;
   IntNode* nodeObj3 = NULL;
   IntNode* currObj  = NULL;
   
   // Front of nodes list
   headObj = new IntNode(-1);
   
   // Insert nodes
   nodeObj1 = new IntNode(555);
   headObj->InsertAfter(nodeObj1);
   
   nodeObj2 = new IntNode(999);
   nodeObj1->InsertAfter(nodeObj2);
   
   nodeObj3 = new IntNode(777);
   nodeObj1->InsertAfter(nodeObj3);
   
   // Print linked list
   currObj = headObj;
   while (currObj != NULL) {
      currObj->PrintNodeData();
      currObj = currObj->GetNext();
   }
   
   return 0;
}