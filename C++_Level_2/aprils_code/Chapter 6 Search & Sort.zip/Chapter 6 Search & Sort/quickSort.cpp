#include <iostream>
using namespace std;

void displayArray(int*, int);
void quickSort(int*, int, int);
int partition(int*, int, int);

int main()
{
	const int SIZE = 5;
	int myArr[SIZE] = {85, 42, 7, 186, 18};
	
	//display the array
	displayArray(myArr, SIZE);
	//sort the array
	quickSort(myArr, 0, SIZE-1);
	//display the array
	displayArray(myArr, SIZE);
	
	return 0;
}

void quickSort(int *arr, int low, int high) 
{
	int pivot_location = 0;

	/* Base case: If there are 1 or zero elements to sort,
	partition is already sorted */
	if (low >= high) {
		return;
	}

	/* Partition the data within the array. Value pivot_location returned
	from partitioning is location of last element in low partition. */
	pivot_location = partition(arr, low, high);

	/* Recursively sort low partition (low to pivot_location) and
	high partition (pivot_location + 1 to high) */
	quickSort(arr, low, pivot_location);
	quickSort(arr, pivot_location + 1, high);
}

int partition(int *arr, int low, int high) {

   int midpoint, pivot, temp;
   bool done = false;
   
   /* Pick middle element as pivot */
   midpoint = low + (high - low) / 2;
   pivot = arr[midpoint];
   
   int l = low;
   int h = high;
   
   while (!done) {
      
      /* Increment l while arr[l] < pivot */
      while (arr[l] < pivot) {
         ++l;
      }
      
      /* Decrement h while pivot < arr[h] */
      while (pivot < arr[h]) {
         --h;
      }
      
      /* If there are zero or one elements remaining,
       all numbers are partitioned. Return h */
      if (l >= h) {
         done = true;
      }
      else {
         /* Swap arr[l] and arr[h],
          update l and h */
         temp = arr[l];
         arr[l] = arr[h];
         arr[h] = temp;
         
         ++l;
         --h;
      }
   }
   
   return h;
}


void displayArray(int *arr, int size)
{
	cout << "\n--------------------The array:  ";
	for(int i=0; i<size; i++)
	{
		cout << arr[i] << " ";
	}
	cout << "--------------------\n";
}