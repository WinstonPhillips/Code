#include "Creature.h"
#include "LinkedList.h"
#include <cctype>
#include <iostream>
#include <fstream>
using namespace std;

void enterMagicalCreature(LinkedList<Creature>*);
void enterMagicalCreatureFromFile(LinkedList<Creature>*);
void deleteCreature(LinkedList<Creature> *);
void printCreatures(LinkedList<Creature> *);
void saveCreaturesToFile(LinkedList<Creature> *);
int binarySearch(LinkedList<Creature> *, string);


int main()
{
	int choice;
	char response;
	
	LinkedList<Creature> creatureList;
		
	do{
	
		cout << "\n\nWhat would you like to do?\n";
		cout << "\t1.  Enter Magical Creature\n";
		cout << "\t2.  Delete a Magical Creature.\n";
		cout << "\t3.  List/Print Creatures.\n";
		cout << "\t4.  End Program.\n";
		cout << "\tEnter 1, 2, 3, or 4.\n";
		cout << "CHOICE:  ";
		cin >> choice;
		
		while(choice < 1 || choice > 4)
		{
			cout << "\nYour choice was invalid.  Choose a number 1 through 4.\n";
			cout << "CHOICE: ";
			cin >> choice;
		}
		
		cout << endl;
		
		switch(choice)
		{
			case 1: //enter creatures
					int enterChoice;
					cout << "\n\nDo you want to enter the creature(s)\n";
					cout << "\t1.  Manually?\n";
					cout << "\t2.  From a file?\n";
					cout << "ENTER 1 or 2:  ";
					cin >> enterChoice;
					while(enterChoice < 1 || enterChoice > 2)
					{
						cout << "\nInvalid choice.  Please enter 1 or 2.\n";
						cout << "ENTER 1 or 2:  ";
						cin >> enterChoice;
					}
					if(enterChoice == 1)
						enterMagicalCreature(&creatureList);	
					else
						enterMagicalCreatureFromFile(&creatureList);
					break;
					
			case 2: deleteCreature(&creatureList);	
					break;
					
			case 3: printCreatures(&creatureList);
					break;
					
			case 4: cout << "\nWould you like to save your creature list to a file? (y or n)  ";
					cin >> response;
					if(tolower(response) == 'y')
						saveCreaturesToFile(&creatureList);
					cout << "\n\nGOODBYE!\n";
					
		} //end of switch
		
	}while(choice != 4);
	
	return 0;
} //end of main

int binarySearch(LinkedList<Creature> *creatureList, string CreatureName)
{
	int position = -1;
	int middle;
	int first = 0;
	int last = creatureList->getLength() - 1;
	bool found = false;
	
	while(first <= last && !found)
	{
		middle = last+first / 2; //find the middle node position
		if(CreatureName == (creatureList->getNodeValue(middle)).getName())
		{
			position = middle;
			found = true;
		}
		else if (CreatureName > (creatureList->getNodeValue(middle)).getName())
		{
			first = middle+1;
		}
		else
		{
			last = middle-1;
		}
	}
	return position;
}

void enterMagicalCreature(LinkedList<Creature> *creatureList)
{
	string name, desc;
	float cost;
	bool dangerous;
	char response;
	int creaturePosition;
	
	do{
		
		
		cout << "\nNAME: ";
		cin.ignore();
		getline(cin, name);
		creaturePosition = binarySearch(creatureList, name);
		if(creaturePosition == -1) //creature doesn't already exist
		{
		
			cout << "\nDESCRIPTION:  ";
			getline(cin, desc);
			
			cout << "\nIS IT A DANGEROUS CREATURE? (y or n):  ";
			cin >> response;
			if(tolower(response) == 'y')
				dangerous = true;
			else
				dangerous = false;
			
			cout << "\nCOST PER MONTH TO CARE FOR CREATURE:  ";
			cin >> cost;
		
			//create a creature
			Creature newCreature(name, desc, dangerous, cost); 
			
			//append creature to the linked list
			creatureList->appendNode(newCreature);
			
			cout << "\nThe " << name << " has been added to the zoo.\n";
		}
		else
		{
			cout << "\nI'm sorry. "  << name << " is a creature that is already at the zoo.\n";
			cout << name << " is node " << creaturePosition+1 << " in the list.\n";
		}
		
		cout << "\n\nWant to add more creatures? (y or n)  ";
		cin >> response;
		
	}while(tolower(response) == 'y');	
}

void enterMagicalCreatureFromFile(LinkedList<Creature> *creatureList)
{
	ifstream inputFile;
	char filename[100];
	cout << "\n\nWhat is the name of the file you want to read from?\n";
	cout << "FILENAME:  ";
	cin.ignore();
	cin.getline(filename, 100);
	
	inputFile.open(filename);
	if(inputFile.fail())
	{
		cout << filename << " does not exist or is corrupt.  Sorry.  Can't load creatures.\n";
	}
	else
	{
		string temp, name, desc;
		float cost;
		bool dangerous;
		char response;
		int numCreatures = 0;
		//load creatures from file
					
		//read first creature name to see if one exists
		getline(inputFile, temp);

		while(!inputFile.eof())  //if we are not at the end of the file, proceed
		{
			name = temp;
			getline(inputFile, desc);
			
			inputFile >> dangerous;
			inputFile >> cost;
			inputFile.ignore();
			
			//create a creature
			Creature newCreature(name, desc, dangerous, cost); 

			//append creature to the linked list
			creatureList->appendNode(newCreature);
			numCreatures++;
			//start reading next line with new creature.						
			getline(inputFile, temp);
			
		}
		
		inputFile.close();
		inputFile.clear();
		
		cout << "\n" << numCreatures << " creatures from " << filename << " have been added to the zoo.\n";
		
	}
}

void deleteCreature(LinkedList<Creature> *creatureList)
{
	int creatureToDelete;
	
	//print all the creatures names
	Creature tempCreature;	
	cout << "The following is a list of all the creatures you take care of:\n";
	for(int x=0; x<creatureList->getLength(); x++)
	{
		tempCreature = creatureList->getNodeValue(x);
		cout << (x) << ") " << tempCreature.getName() << "\n";
	}
	cout << "\n\n";
	cout << "What creature do you wish to remove?\n";
	cout << "CREATURE NUMBER: ";
	cin >> creatureToDelete;

	while(creatureToDelete < 1 || creatureToDelete > creatureList->getLength())
	{
		cout << "\nThat number wasn't in the list of creatures.\n";
		cout << "Enter a number between 1 and " << creatureList->getLength() << ".\n";
		cout << "CREATURE NUMBER: ";
		cin >> creatureToDelete;
	}
	
	creatureList->deleteNode(creatureToDelete);
	cout << "\nYou have removed the creature.\n";
}

void printCreatures(LinkedList<Creature> *creatureList)
{
	Creature tempCreature;
	if(creatureList->getLength() == 0)
	{
		cout << "------------------------------------------------------------------------" << endl;
		cout << "THERE ARE NO CREATURES AT YOUR ZOO!\n";
		cout << endl;
	}
	else
	{
		for(int x = 0; x < creatureList->getLength(); x++)
		{
			tempCreature = creatureList->getNodeValue(x);
			cout << "------------------------------------------------------------------------" << endl;
			cout << "CREATURE " << x+1 << ":  \n";
			tempCreature.printCreature();
		}
	}
}

void saveCreaturesToFile(LinkedList<Creature> *creatureList)
{
	string filename;
	Creature tempCreature;
	
	if(creatureList->getLength() == 0)
	{
		cout << "------------------------------------------------------------------------" << endl;
		cout << "THERE ARE NO CREATURES AT YOUR ZOO!\n";
		cout << endl;
	}
	else
	{
		cout << "\n\nWhat do you want the filename to be?\n";
		cout << "FILENAME:  ";
		cin >> filename;
		cout << endl;
		for(int x = 0; x < creatureList->getLength(); x++)
		{
			tempCreature = creatureList->getNodeValue(x);
			tempCreature.printCreatureToFile(filename);
		}
	}
}
