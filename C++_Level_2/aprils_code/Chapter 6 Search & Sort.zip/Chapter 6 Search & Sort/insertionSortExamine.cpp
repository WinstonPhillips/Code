#include <iostream>
using namespace std;

void displayArray(int*, int);
void insertionSort(int*, int);

int main()
{
	int myArr[5] = {85, 42, 7, 186, 18};
	
	//display the array
	displayArray(myArr, 5);
	//sort the array
	insertionSort(myArr, 5);
	//display the array
	displayArray(myArr, 5);
	
	return 0;
}

void insertionSort(int *arr, int size)
{
	int tempForSwap;
	int t=0;
	cout << "\nSorting the array with the Insertion Sort algorithm.\n\n";
	//minElement will hold the subscript of the minimum element 
	//that is to be compared to its immediate neighbor
	for(int minElement=1; minElement < size; minElement++)
	{
		cout << "\n\nTRAVERSAL NUMBER " << t+1 << "-------------------------------------------------";
		for(int i=minElement; i > 0; i--) //using i for "index"
		{
			cout << "\nComparing " << arr[i] << " & " << arr[i+1];
			if(arr[i] < arr[i-1])
			{
				cout << "\nSwapping " << arr[i] << " & " << arr[i+1];
				//swap the two adjacent elements
				tempForSwap = arr[i];
				arr[i] = arr[i-1];
				arr[i-1] = tempForSwap;
			}
			else
				cout << "\nDid not swap.";
		}
		displayArray(arr, 5);
		t++;
	}
}


void displayArray(int *arr, int size)
{
	cout << "\n--------------------The array:  ";
	for(int i=0; i<size; i++)
	{
		cout << arr[i] << " ";
	}
	cout << "--------------------\n";
}