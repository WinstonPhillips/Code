#include <iostream>
using namespace std;
int getTotalArrayElements(int[], int, int);

const int SIZE = 5;

int main()
{
	int myArr[SIZE] = {7, 14, 1, 5, 3};
	
	cout << "\n\nThe total of the array elements:  " << getTotalArrayElements(myArr,0,SIZE) << endl << endl;
	
	return 0;
}

int getTotalArrayElements(int arr[], int pos, int size)
{
	if(pos < size)
	{
		return getTotalArrayElements(arr, pos+1, size) + arr[pos];
	}
	else
		return 0;
}
