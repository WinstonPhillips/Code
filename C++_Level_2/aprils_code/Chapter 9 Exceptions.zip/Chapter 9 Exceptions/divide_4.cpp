#include <iostream>
#include <stdexcept> //library needed to use runtime_error class
/*  link:  http://www.cplusplus.com/reference/stdexcept/runtime_error/ */

using namespace std;
double divide(int, int);

int main()
{
	int n, d;
	double quotient;
	cout << "\n\nEnter in a numerator:  ";
	cin >> n;
	cout << "\nEnter in a denominator:  ";
	cin >> d;

	try{
		quotient = divide(n, d);
		cout << "\n\nThe result is " << quotient << endl << endl;
	}
	catch(runtime_error& except) {
		cout << "\n" << except.what() << "\n\n";
	}	
	cout << "\n\nEnd of program.\n\n";
	return 0;
}
double divide(int numerator, int denominator)
{
	if(denominator == 0)
	{
		throw runtime_error("ERROR:  Cannot divide by zero.");
	}
	else
		return static_cast<double>(numerator)/denominator;
}

