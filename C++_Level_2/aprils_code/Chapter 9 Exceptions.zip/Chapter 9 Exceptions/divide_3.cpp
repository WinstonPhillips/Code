#include <iostream>
using namespace std;
double divide(int, int);

int main()
{
	int n, d;
	double quotient;
	cout << "\n\nEnter in a numerator:  ";
	cin >> n;
	cout << "\nEnter in a denominator:  ";
	cin >> d;
	try{
		quotient = divide(n, d);
		cout << "\n\nThe result is " << quotient << endl << endl;
	}
	catch(string exceptionString) {
		cout << exceptionString;
	}	
	cout << "\n\nEnd of program.\n\n";
	return 0;
}
double divide(int numerator, int denominator)
{
	if(denominator == 0)
	{
		string exceptionString =  "\nERROR:  Cannot divide by zero.\n\n";
		throw exceptionString;
	}
	else
		return static_cast<double>(numerator)/denominator;
}

