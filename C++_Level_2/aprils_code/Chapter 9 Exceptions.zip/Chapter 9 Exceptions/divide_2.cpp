#include <iostream>
using namespace std;
double divide(int, int);

int main()
{
	int n, d;
	cout << "\n\nEnter in a numerator:  ";
	cin >> n;
	cout << "\nEnter in a denominator:  ";
	cin >> d;
	cout << "\n\nThe result is " << divide(n, d) << endl << endl;
	
	return 0;
}
double divide(int numerator, int denominator)
{
	if(denominator == 0)
	{
		throw "ERROR:  Cannot divide by zero.";
		return 0;
	}
	else
		return static_cast<double>(numerator)/denominator;
}

